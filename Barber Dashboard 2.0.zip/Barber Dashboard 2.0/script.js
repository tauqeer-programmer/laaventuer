document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item');
    const contentSections = document.querySelectorAll('.content-section');
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const notificationBell = document.getElementById('notification-bell');
    const notificationPopup = document.getElementById('notification-popup');
    const closeBtn = document.querySelector('.close-btn');
    const userProfile = document.getElementById('user-profile');

    // Chart instances
    let dailyEarningsChart, staffBookingChart;

    // Function to initialize charts
    const initializeCharts = () => {
        // Daily Earnings Chart (Line Chart)
        const dailyEarningsCtx = document.getElementById('dailyEarningsChart').getContext('2d');
        dailyEarningsChart = new Chart(dailyEarningsCtx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Daily Earnings ($)',
                    data: [500, 750, 600, 900, 1200, 1500, 800],
                    borderColor: '#4a90e2',
                    backgroundColor: 'rgba(74, 144, 226, 0.2)',
                    tension: 0.4,
                    pointRadius: 5
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        // Staff Booking Chart (Pie Chart)
        const staffBookingCtx = document.getElementById('staffBookingChart').getContext('2d');
        staffBookingChart = new Chart(staffBookingCtx, {
            type: 'pie',
            data: {
                labels: ['Available', 'Booked', 'Unavailable'],
                datasets: [{
                    label: 'Staff Status',
                    data: [12, 5, 1], // Example data: 12 available, 5 booked, 1 unavailable
                    backgroundColor: [
                        '#2ecc71', // Available (Green)
                        '#4a90e2', // Booked (Blue)
                        '#e74c3c'  // Unavailable (Red)
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    };

    // Main navigation logic
    const setActiveSection = (targetSectionId) => {
        navItems.forEach(nav => nav.classList.remove('active'));
        contentSections.forEach(section => section.classList.remove('active'));
        
        const activeNavItem = document.querySelector(`.nav-item[data-section="${targetSectionId}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }

        const targetSection = document.getElementById(targetSectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Re-initialize charts if the dashboard section is active
        if (targetSectionId === 'dashboard' && !dailyEarningsChart) {
            initializeCharts();
        }
    };

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetSectionId = item.getAttribute('data-section');
            setActiveSection(targetSectionId);
            
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('open');
                document.body.classList.remove('menu-open');
            }
        });
    });

    // Mobile menu toggle logic
    menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        document.body.classList.toggle('menu-open');
    });

    // Close menu when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
            document.body.classList.remove('menu-open');
        }
    });

    // Notification pop-up logic
    notificationBell.addEventListener('click', () => {
        notificationPopup.classList.add('show');
        document.querySelector('.notification-dot').style.display = 'none';
    });

    closeBtn.addEventListener('click', () => {
        notificationPopup.classList.remove('show');
    });

    window.addEventListener('click', (e) => {
        if (e.target === notificationPopup) {
            notificationPopup.classList.remove('show');
        }
    });

    // Profile dropdown toggle logic
    userProfile.addEventListener('click', (e) => {
        e.stopPropagation();
        userProfile.classList.toggle('active');
    });

    // Close profile dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!userProfile.contains(e.target) && userProfile.classList.contains('active')) {
            userProfile.classList.remove('active');
        }
    });
    
    // Initialize the dashboard to show the 'dashboard' section by default
    if (!document.querySelector('.content-section.active')) {
        setActiveSection('dashboard');
    }
});