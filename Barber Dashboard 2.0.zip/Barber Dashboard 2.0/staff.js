document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item');
    const contentSections = document.querySelectorAll('.content-section');
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const userProfile = document.getElementById('user-profile');
    const addStaffBtn = document.getElementById('add-staff-btn');
    const addStaffModal = document.getElementById('add-staff-modal');
    const addStaffForm = document.getElementById('add-staff-form');
    const staffListContainer = document.getElementById('staff-list');
    const modalCloseButtons = document.querySelectorAll('.modal .close-btn');

    // Sample Staff Data
    let staffData = [
        { id: 1, name: 'Ali Raza', specialty: 'Haircut, Shave', status: 'Available' },
        { id: 2, name: 'Bilal Khan', specialty: 'Haircut', status: 'Booked' },
        { id: 3, name: 'Usman Ali', specialty: 'Haircut, Color', status: 'Available' },
        { id: 4, name: 'Fahad Tariq', specialty: 'Haircut', status: 'On Break' },
    ];

    // Function to render the staff list
    const renderStaffList = () => {
        staffListContainer.innerHTML = '';
        if (staffData.length === 0) {
            staffListContainer.innerHTML = `<div class="placeholder-content"><p>No staff members found.</p></div>`;
            return;
        }

        staffData.forEach(staff => {
            const staffCard = document.createElement('div');
            staffCard.className = 'staff-card';
            staffCard.dataset.id = staff.id;
            
            let statusClass = '';
            if (staff.status === 'Available') {
                statusClass = 'status-available';
            } else if (staff.status === 'Booked') {
                statusClass = 'status-booked';
            } else if (staff.status === 'On Break') {
                statusClass = 'status-on-break';
            }

            staffCard.innerHTML = `
                <p>${staff.name}</p>
                <p>${staff.specialty}</p>
                <div><span class="staff-status ${statusClass}">${staff.status}</span></div>
                <div>
                    <button class="remove-staff-btn">
                        <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                    </button>
                </div>
            `;
            staffListContainer.appendChild(staffCard);
        });
    };

    // Function to handle adding a new staff member
    const addStaff = (event) => {
        event.preventDefault();
        const formData = new FormData(addStaffForm);
        const newStaff = {
            id: Date.now(),
            name: formData.get('name'),
            specialty: formData.get('specialty'),
            status: formData.get('status'),
        };
        staffData.push(newStaff);
        renderStaffList();
        addStaffForm.reset();
        addStaffModal.classList.remove('show');
    };

    // Function to handle removing a staff member
    const removeStaff = (event) => {
        if (event.target.closest('.remove-staff-btn')) {
            const card = event.target.closest('.staff-card');
            const staffId = parseInt(card.dataset.id);
            staffData = staffData.filter(staff => staff.id !== staffId);
            renderStaffList();
        }
    };

    // Main navigation logic
    const setActiveSection = (targetSectionId) => {
        navItems.forEach(nav => nav.classList.remove('active'));
        contentSections.forEach(section => section.classList.remove('active'));
        
        const activeNavItem = document.querySelector(`.nav-item[data-section="${targetSectionId}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }

        const targetSection = document.getElementById(targetSectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }
        
        if (targetSectionId === 'staff') {
            renderStaffList();
        }
    };

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetSectionId = item.getAttribute('data-section');
            setActiveSection(targetSectionId);
            
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('open');
                document.body.classList.remove('menu-open');
            }
        });
    });

    // Mobile menu toggle logic
    menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        document.body.classList.toggle('menu-open');
    });

    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('open')) {
            sidebar.classList.remove('open');
            document.body.classList.remove('menu-open');
        }
    });

    // Modal close buttons
    modalCloseButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.target.closest('.modal').classList.remove('show');
        });
    });

    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('show');
        }
    });

    // Staff page specific event listeners
    addStaffBtn.addEventListener('click', () => {
        addStaffModal.classList.add('show');
    });

    addStaffForm.addEventListener('submit', addStaff);
    staffListContainer.addEventListener('click', removeStaff);
    
    // Set 'staff' as the default active section on page load
    const initialActiveSection = document.querySelector('.content-section.active');
    if (initialActiveSection) {
        setActiveSection(initialActiveSection.id);
    }
});